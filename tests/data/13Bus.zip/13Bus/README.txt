This is a copy of the 13Bus folder which is distributed with OpenDSS.
Besides fixing filenames for case-sensitive filesystems, the folder is compressed into a ZIP file for testing.

The source files should be available at:

    https://sourceforge.net/p/electricdss/code/HEAD/tree/trunk/Version8/Distrib/IEEETestCases/13Bus/
    
and our (DSS Extensions) copy is at:

    https://github.com/dss-extensions/electricdss-tst/tree/master/Version8/Distrib/IEEETestCases/13Bus
